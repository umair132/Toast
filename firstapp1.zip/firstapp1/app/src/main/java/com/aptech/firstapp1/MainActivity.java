package com.aptech.firstapp1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Button submit;
    private EditText data;
    private TextView show;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       submit = findViewById(R.id.submitID);
       data = findViewById(R.id.numberID);
       show = findViewById(R.id.showID);

       submit.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               String Data = data.getText().toString();

               show.setText(Data);

               Toast.makeText(MainActivity.this, Data, Toast.LENGTH_SHORT).show();
           }
       });

    }
}